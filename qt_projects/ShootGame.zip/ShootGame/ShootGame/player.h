#ifndef MYRECT_H
#define MYRECT_H

#include "bullet.h"
#include <QObject>
#include <QGraphicsPixmapItem>
#include <QPolygonF>
#include <QVector>
#include <QPointF>
#include <QGraphicsPolygonItem>
#include <QList>

class Player : public QObject, public QGraphicsPixmapItem{
    Q_OBJECT
public:
    Player();
    double distanceTo(QGraphicsItem* item);
    void createColidinModel();
    void shoot();
    void keyPressEvent(QKeyEvent *event);
    ~Player();
public:

    QGraphicsPolygonItem* colidinModel;
    const int scaleFaktor = 9;
    const int width = 35;
    const int height = 34;
};

#endif // MYRECT_H
