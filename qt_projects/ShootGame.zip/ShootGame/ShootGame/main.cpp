#include <QApplication>
#include <time.h>
#include <stdlib.h>
#include "game.h"

int main(int argc, char *argv[]){
    srand (time(NULL));
    QApplication a (argc,argv);

    Game game;

    a.exec();
}
