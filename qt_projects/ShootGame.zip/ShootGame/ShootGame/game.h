#ifndef GAME_H
#define GAME_H


#include <QGraphicsScene>
#include <QObject>
#include <QTimer>
#include <QGraphicsView>
#include "player.h"
#include "enemy.h"
#include "bullet.h"


class Game : public QGraphicsView{
    Q_OBJECT
public:
    Game();
    ~Game();
    void createEnemies(int numberOfEnemies);
    void spawnEnemy();

private:
    Player* player;

    QGraphicsScene* map;
    QGraphicsView* view;

    QTimer* spawnTimer;
    int enemiesSpawned;
    int maxEnemiesCount;

     QList<QPointF> pointsToPlayer;

private:
     const int rectWidth = 40;
     const int rectHeight = 40;

};

#endif // GAME_H
