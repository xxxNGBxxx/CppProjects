#include "bullet.h"
#include <QDebug>


Bullet::Bullet(){
     setPixmap(QPixmap(":/data/circle.tga"));
     QTimer* timer = new QTimer;
     connect(timer,&QTimer::timeout,this,&Bullet::move);
     timer->start(50);
}

void Bullet::move(){
    QList<QGraphicsItem* > coliding = collidingItems();
    for(int i = 0, j = coliding.size(); i < j; ++i){
        if(typeid(*(coliding[i])) == typeid(Enemy)){
            scene()->removeItem(coliding[i]);
            scene()->removeItem(this);
            delete this;
            return;
        }
    }
    setPos(x()+10, y() );
    //QLineF line(QPointF(x(), y()), attackDestination);
    //double angle = line.angle();
    //setRotation(angle);
    if(pos().x() > 800){
        scene()->removeItem(this);
        delete this;
    }
    else if(pos().x() > 800){
        scene()->removeItem(this);
        delete this;
    }
    else if(pos().y() < 0){
        scene()->removeItem(this);
        delete this;
    }
    else if(pos().y() > 600){
        scene()->removeItem(this);
        delete this;
    }
}
