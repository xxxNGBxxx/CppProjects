#include "game.h"

Game::Game() {

    map = new QGraphicsScene(this);

    setScene(map);

    view = new QGraphicsView(map);

    player = new Player;
    player->setPos(view->width() / 2 + player->width,view->height() / 2 + player->height);

    spawnTimer = new QTimer(this);

    pointsToPlayer << QPointF(view->width() / 2 + player->width,view->height() / 2 + player->height);

    view->setFixedSize(800,600);

    view->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    view->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    map->setSceneRect(0,0,1000,1000);
    map->addItem(player);
    map->setBackgroundBrush(Qt::gray);

    createEnemies(10);

    view->show();

}

Game::~Game(){
    delete player;
    delete map;
    delete spawnTimer;
    delete view;
}

void Game::createEnemies(int numberOfEnemies){
    enemiesSpawned = 0;
    maxEnemiesCount = numberOfEnemies;
    connect(spawnTimer,&QTimer::timeout,this,&Game::spawnEnemy);
    spawnTimer->start(2000);
}

void Game::spawnEnemy(){
    Enemy* enemy = new Enemy(pointsToPlayer);
    map->addItem(enemy);
    enemiesSpawned += 1;
    if(enemiesSpawned >= maxEnemiesCount){
        spawnTimer->disconnect();
    }
}





