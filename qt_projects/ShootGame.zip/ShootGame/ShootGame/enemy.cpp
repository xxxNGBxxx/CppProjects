#include "enemy.h"

Enemy::Enemy(QList<QPointF> pointsToTarget): QObject (){
    setPixmap(QPixmap(":/data/enemy.png"));
    setPos(randX,randY);
    points = pointsToTarget;
    pointIndex = 0;
    destination = points[0];
    rotateToPoint(destination);

    timer = new QTimer;
    connect(timer, &QTimer::timeout,this,&Enemy::moveToTarget);
    timer->start(150);
    //createColidinModel();
}

void Enemy::rotateToPoint(QPointF p){
    QLineF line(pos(),p);
    setRotation(line.angle() * -1);
}

void Enemy::createColidinModel(){
    QVector<QPointF> enemyPolygon;
    enemyPolygon << QPointF(1,0) << QPointF(2,0) << QPointF(3,1) << QPointF(3,2)
                  << QPointF(2,3) << QPointF(1,3) << QPointF(0,2) << QPointF(0,1);

    for(int i = 0, j = enemyPolygon.size(); i < j; i++){
        enemyPolygon[i] *= scaleFaktor;
    }

    QPolygonF polygon(enemyPolygon);
    colidinModel = new QGraphicsPolygonItem(polygon,this);

    QPointF polyCenter(1.5, 1.5);
    polyCenter *= scaleFaktor;
    polyCenter = mapToScene(polyCenter);

    QPointF enemyCenter(x() + width / 2, y() + height / 2 );
    QLineF lineTo(polyCenter,enemyCenter);
    colidinModel->setPos(x() + lineTo.dx(), y() + lineTo.dy());
}

Enemy::~Enemy(){
    delete timer;
}

void Enemy::moveToTarget(){
    QLineF line(pos(),destination);
    if(line.length() < 5){
        pointIndex++;
        if(pointIndex >= points.size()){
            return;
        }
        destination = points[pointIndex];
        rotateToPoint(destination);
    }

    double stepSize = 5;
    double theta = rotation();
    double dy = stepSize * qSin(qDegreesToRadians(theta));
    double dx = stepSize * qCos(qDegreesToRadians(theta));

    setPos(x() + dx, y() + dy);
    QList<QGraphicsItem* > coliding = collidingItems();
    for(int i = 0, j = coliding.size(); i < j; ++i){
        if(typeid(*(coliding[i])) == typeid(Player)){
            scene()->removeItem(coliding[i]);
            exit(0);
        }
    }
}

