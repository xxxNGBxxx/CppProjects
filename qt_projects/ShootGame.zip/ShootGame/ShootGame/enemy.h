#ifndef ENEMY_H
#define ENEMY_H

#include <QObject>
#include <QTimer>
#include <QGraphicsPixmapItem>
#include <QList>
#include <QPointF>
#include <QLineF>
#include <qmath.h>
#include <QGraphicsScene>
#include "player.h"

class Enemy : public QObject, public QGraphicsPixmapItem {
    Q_OBJECT
public:
    Enemy(QList<QPointF> pointsToTarget);
    void rotateToPoint(QPointF p);
    void createColidinModel();
    ~Enemy();
private:
    QList<QPointF> points;
    QPointF destination;
    int pointIndex;

    QTimer* timer;
    QGraphicsPolygonItem* colidinModel;

    const int scaleFaktor = 9;
    const int width = 35;
    const int height = 34;

    int randX = rand() % 800;
    int randY = rand() % 600;
public slots:
    void moveToTarget();
};

#endif // ENEMY_H
