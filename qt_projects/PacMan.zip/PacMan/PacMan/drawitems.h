#ifndef STARTEXIT_H
#define STARTEXIT_H
#include <QGraphicsRectItem>
#include <QVector>
#include <QPointF>


// this class draw rectangle and create coliding model of it

class DrawItems : public QGraphicsRectItem{
public:
    DrawItems(const int &width, const int &height);
    void createColidinModel();
    void drawRect(int x, int y, int width, int height);
    ~DrawItems();
private:
    QGraphicsPolygonItem* colidinModel;
    const int scaleFaktor = 13;
    const int width = 40;
    const int height = 40;
    };

#endif // STARTEXIT_H
