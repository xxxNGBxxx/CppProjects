#ifndef GAME_H
#define GAME_H

#include <QGraphicsScene>
#include <QObject>
#include <QTimer>
#include <QGraphicsView>
#include "player.h"
#include "enemy.h"
#include "drawitems.h"
#include <QPen>
#include "stars.h"



class Game : public QGraphicsView{
    Q_OBJECT
public:
    Game();
    ~Game();
    void createEnemies(int numberOfEnemies);
    void spawnEnemy();
    void drawLv1();
    void addStar(int numberOfStars);
    void spawnStar();
private:
    Player* player;

    QGraphicsScene* map;

    DrawItems* exit;
    DrawItems* start;

    QTimer* spawnTimer;
    int enemiesSpawned;
    int maxEnemiesCount;

    QTimer* starTimer;
    int starSpawned;
    int maxStarCount;
    Stars* star;

    QList<QPointF> pointsToPlayer;

private:
     const int rectWidth = 40;
     const int rectHeight = 40;

};

#endif // GAME_H
