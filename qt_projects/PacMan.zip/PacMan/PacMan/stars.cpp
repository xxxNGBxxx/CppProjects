#include "stars.h"

Stars::Stars(): QObject (){
    setPixmap(QPixmap(":/img/stars.png"));
    setPos(randX,randY);
}
