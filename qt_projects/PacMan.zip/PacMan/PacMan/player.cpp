#include "player.h"

Player::Player(){

    setPixmap(QPixmap(":/img/player.png"));
    setFlag(QGraphicsPixmapItem::ItemIsFocusable);
    setFocus();
    createColidinModel();
}

void Player::keyPressEvent(QKeyEvent *event){
    if(event->key() == Qt::Key_Left){
        if(pos().x() > 9){
            setPos(x() - 10, y());
        }
    }
    else if(event->key() == Qt::Key_Right){
        if(pos().x() < 800 - 40){
            setPos(x() + 10, y());
        }
    }
    else if(event->key() == Qt::Key_Up){
         if(pos().y() > 9){
            setPos(x(), y() - 10);
         }
    }
    else if(event->key() == Qt::Key_Down){
        if(pos().y() < 600 - 40){
            setPos(x(), y() + 10);
        }
    }
}

double Player::distanceTo(QGraphicsItem *item){
    QLineF line(pos(),item->pos());
    return line.length();
}

void Player::createColidinModel(){
    QVector<QPointF> playerPolygon;
    playerPolygon << QPointF(1,0) << QPointF(2,0) << QPointF(3,1) << QPointF(3,2)
                  << QPointF(2,3) << QPointF(1,3) << QPointF(0,2) << QPointF(0,1);

    for(int i = 0, j = playerPolygon.size(); i < j; i++){

        playerPolygon[i] *= scaleFaktor;
    }

    QPolygonF polygon(playerPolygon);
    colidinModel = new QGraphicsPolygonItem(polygon,this);

    QPointF polyCenter(1.5,1.5);
    polyCenter *= scaleFaktor;
    polyCenter = mapToScene(polyCenter);

    QPointF playerCenter(x() + width / 2,y() + height / 2);
    QLineF line(polyCenter,playerCenter);
    colidinModel->setPos(x() + line.dx(), y() + line.dy());
}

Player::~Player(){
    delete colidinModel;
}
