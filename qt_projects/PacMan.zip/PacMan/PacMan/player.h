#ifndef PLAYER_H
#define PLAYER_H

#include <QKeyEvent>
#include <QGraphicsPixmapItem>
#include <QPolygonF>
#include <QVector>
#include <QPointF>
#include <QGraphicsPolygonItem>

class Player : public QGraphicsPixmapItem{

public:
    Player();
    void keyPressEvent(QKeyEvent* event);
    double distanceTo(QGraphicsItem* item);
    void createColidinModel();
    ~Player();
private:
    QGraphicsPolygonItem* colidinModel;
    const int scaleFaktor = 9;
    const int width = 35;
    const int height = 34;
};

#endif // PLAYER_H
