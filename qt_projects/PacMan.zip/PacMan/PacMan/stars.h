#ifndef STARS_H
#define STARS_H

#include <stdlib.h>
#include <time.h>
#include <QGraphicsPixmapItem>
#include <QObject>

class Stars: public QObject, public QGraphicsPixmapItem{
    Q_OBJECT
public:
    Stars();
private:
    int randX = rand() % 800;
    int randY = rand() % 600;
};

#endif // STARS_H
