#include "game.h"


Game::Game() {
    star = new Stars;
    map = new QGraphicsScene(this);

    setScene(map);

    player = new Player;

    spawnTimer = new QTimer(this);

    pointsToPlayer << QPointF(player->pos().x(),player->pos().y())
                   << QPointF(player->pos().x(),player->pos().y())
                   << QPointF(player->pos().x(),player->pos().y());

    exit = new DrawItems(rectWidth,rectHeight);
    start = new DrawItems(rectWidth,rectHeight);

    map->addItem(exit);
    map->addItem(start);
    map->addItem(player);


    start->setPos(400,555);
    exit->setPos(1,1);
    player->setPos(start->x(), start->y());

    setFixedSize(800,600);
    map->setSceneRect(0,0,800,600);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    map->setBackgroundBrush(Qt::gray);
    start->setBrush(Qt::green);
    exit->setBrush(Qt::red);

     createEnemies(2);
     drawLv1();

}

Game::~Game(){
    delete player;
    delete map;
    delete exit;
    delete start;
    delete spawnTimer;
    delete starTimer;
    delete star;
}

void Game::createEnemies(int numberOfEnemies){
    enemiesSpawned = 0;
    maxEnemiesCount = numberOfEnemies;
    connect(spawnTimer,&QTimer::timeout,this,&Game::spawnEnemy);
    spawnTimer->start(2000);
}

void Game::spawnEnemy(){
    Enemy* enemy = new Enemy(pointsToPlayer);
    enemy->setPos(pointsToPlayer[0]);
    map->addItem(enemy);
    enemiesSpawned += 1;
    if(enemiesSpawned >= maxEnemiesCount){
        spawnTimer->disconnect();
    }
}

void Game::drawLv1(){
    QPen pen(Qt::lightGray);

    map->addLine(0,100,200,100,pen);
    map->addLine(300,100,500,100,pen);
    map->addLine(600,0,600,100,pen);
    map->addLine(700,100,800,100,pen);
    map->addLine(200,100,200,300,pen);
    map->addLine(100,200,100,300,pen);
    map->addLine(100,300,200,300,pen);
    map->addLine(200,400,200,500,pen);
    map->addLine(100,500,200,500,pen);
    map->addLine(100,500,100,600,pen);
    map->addLine(300,100,300,500,pen);
    map->addLine(400,100,400,200,pen);
    map->addLine(500,100,500,200,pen);
    map->addLine(400,300,400,400,pen);
    map->addLine(500,200,600,200,pen);
    map->addLine(700,100,700,200,pen);
    map->addLine(500,300,600,300,pen);
    map->addLine(500,400,600,400,pen);
    map->addLine(600,400,600,500,pen);
}
/*
void Game::spawnStar(){
    star = new Stars;
    map->addItem(star);
    starSpawned += 1;
    if(starSpawned >= maxStarCount){
        starTimer->disconnect();
    }
}

void Game::addStar(int numberOfStars){
    starSpawned = 0;
    maxStarCount = numberOfStars;
    connect(starTimer,&QTimer::timeout,this,&Game::spawnStar);
    starTimer->start(50);
}
*/
