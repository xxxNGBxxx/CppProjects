#include "drawitems.h"


DrawItems::DrawItems(const int &width, const int &height){
    setRect(0,0,width,height);
    createColidinModel();
}

void DrawItems::createColidinModel(){
    QVector<QPointF> rectPolygon;
    rectPolygon << QPointF(1,0) << QPointF(2,0) << QPointF(3,1) << QPointF(3,2)
                  << QPointF(2,3) << QPointF(1,3) << QPointF(0,2) << QPointF(0,1);

    for(int i = 0, j = rectPolygon.size(); i < j; i++){
        rectPolygon[i] *= scaleFaktor;
    }

    QPolygonF polygon(rectPolygon);
    colidinModel = new QGraphicsPolygonItem(polygon,this);

    QPointF polyCenter(1.5, 1.5);
    polyCenter *= scaleFaktor;
    polyCenter = mapToScene(polyCenter);

    QPointF rectCenter(x() + width / 2, y() + height / 2 );
    QLineF lineTo(polyCenter,rectCenter);
    colidinModel->setPos(x() + lineTo.dx(), y() + lineTo.dy());
}

void DrawItems::drawRect(int x, int y, int width, int height){
    setRect(x,y,width,height);
}

DrawItems::~DrawItems(){
    delete colidinModel;
}

